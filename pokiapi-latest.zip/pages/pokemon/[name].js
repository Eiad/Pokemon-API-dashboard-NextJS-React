// pages/pokemon/[name].js
import React from "react";
import { useRouter } from "next/router";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import dynamic from "next/dynamic";

// Dynamically import ApexCharts to avoid SSR issues with window object
const ReactApexChart = dynamic(() => import("react-apexcharts"), {
  ssr: false,
});

function PokemonPage() {
  const router = useRouter();
  const { name } = router.query;

  // Function to generate a random number for the Pokemon image generator
  const getRandomImageId = () => Math.floor(Math.random() * 400) + 1;

  // Fetch the Pokémon details
  const { data, status } = useQuery({
    queryKey: ["pokemon", name],
    queryFn: () =>
      axios
        .get(`https://pokeapi.co/api/v2/pokemon/${name}`)
        .then((res) => res.data),
    enabled: !!name,
  });

  // Prepare stats data for the graph
  const chartData = data?.stats.map((stat) => ({
    name: stat.stat.name.replace("-", " "),
    data: [stat.base_stat],
  }));

  const options = {
    chart: {
      type: "radar",
      toolbar: {
        show: true,
      },
      dropShadow: {
        enabled: true,
        blur: 3,
        left: 1,
        top: 1,
        opacity: 0.1,
      },
    },
    title: {
      align: "center",
      style: {
        fontSize: "20px",
        fontWeight: "bold",
        color: "#333",
      },
    },
    stroke: {
      width: 2,
    },
    fill: {
      opacity: 0.7,
    },
    markers: {
      size: 5,
      hover: {
        size: 8,
      },
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return val;
        },
      },
    },
    xaxis: {
      categories: chartData?.map((stat) => stat.name),
      labels: {
        style: {
          colors: [],
          fontSize: "12px",
        },
      },
    },
    yaxis: {
      tickAmount: 5,
      labels: {
        formatter: function (val) {
          return Math.floor(val);
        },
        style: {
          color: "#000",
          fontSize: "12px",
        },
      },
    },
    legend: {
      position: "bottom",
      horizontalAlign: "center",
      markers: {
        width: 10,
        height: 10,
        radius: 20,
      },
      itemMargin: {
        horizontal: 10,
        vertical: 10,
      },
    },
    responsive: [
      {
        breakpoint: 480,
        options: {
          chart: {
            height: 300,
          },
          legend: {
            position: "top",
          },
        },
      },
    ],
  };

  const series = [
    {
      name: "Stats",
      data: chartData?.map((stat) => stat.data[0]),
    },
  ];

  if (status === "loading") return <p>Loading...</p>;
  if (status === "error") return <p>Error loading data...</p>;

  return (
    <>
      <div>
        <h1 className="text-center">{data?.name.toUpperCase()}'s base state</h1>
      </div>

      <div className="text-center">
        <div>
          {" "}
          <img
            src={`https://lorempokemon.fakerapi.it/pokemon/200/${getRandomImageId()}`}
            loading="lazy"
          />
        </div>
        <div>
          {/* Render the graph here */}
          {chartData && (
            <ReactApexChart
              options={options}
              series={series}
              type="radar"
              height={650}
            />
          )}
        </div>
      </div>
    </>
  );
}

export default PokemonPage;
