// pages/index.js
import { useQuery } from "@tanstack/react-query";
import styled from "styled-components";
import axios from "axios";
import Link from "next/link";

const CategoryList = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 10px;
`;

const CategoryItem = styled.a`
  padding: 20px;
  margin: 5px;
  background: #f2f2f2;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
  &:hover {
    background-color: #ddd;
  }
`;

export default function Home() {
  // Updated React Query useQuery hook to match v5 syntax
  const { data, status } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const response = await axios.get("https://pokeapi.co/api/v2/type");
      return response.data.results;
    },
  });

  if (status === "loading") return <p>Loading...</p>;
  if (status === "error") return <p>Error fetching data</p>;

  return (
    <>
      <header className="header">
        <h1 className="title">Pokémon World</h1>
        <p className="subtitle">Discover and explore the types of Pokémon</p>
      </header>
      <section className="guide-section">
        <div className="step">
          <span className="step-number">1.</span>
          <span className="step-description">
            Select a Pokémon type to see all associated Pokémon.
          </span>
        </div>
        <div className="step">
          <span className="step-number">2.</span>
          <span className="step-description">
            Choose a Pokémon to learn more about its abilities and
            characteristics.
          </span>
        </div>
        <div className="step">
          <span className="step-number">3.</span>
          <span className="step-description">
            Enjoy exploring the diverse world of Pokémon!
          </span>
        </div>
      </section>
      <div className="CategoryList">
        {data?.map((category) => (
          <Link
            className="CategoryItem"
            href={`/category/${category.name}`}
            key={category.name}
            passHref
          >
            {category.name}
          </Link>
        ))}
      </div>
    </>
  );
}
